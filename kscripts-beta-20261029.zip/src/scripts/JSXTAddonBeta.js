// ---------- JSXTAddon Script ----------
// Runs StarXTerminator on large images panel by panel: N x N overlapping
// panels, joined back with feathered blending in the overlap zones.
// part of • kScript Bundle •
// made with love by Igor Koprowicz (koperson)
// check out my astrobin https://www.astrobin.com/users/koperson/
// idea by Jędrzej Adaszek
// ---------------------------------------------

#feature-id JSXTAddonBeta : kScripts Beta > JSXTAddon
#feature-info JSXTAddon - StarXTerminator in overlapping panels for large images, idea by Jędrzej Adaszek
#define TITLE "JSXTAddon"
#define VER "1.0-beta1"

#engine v8

// Grid size range and default overlaps (used by Dialog.js, defined before the includes)
#define JX_MIN_PANELS 2
#define JX_MAX_PANELS 8
#define JX_DEFAULT_OVERLAP_PX 256
#define JX_DEFAULT_OVERLAP_PERCENT 10

#include <pjsr/StdIcon.jsh>
#include <pjsr/StdButton.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/DataType.jsh>
#include <pjsr/UndoFlag.jsh>

#include "kScriptsBeta/lib/JSXTAddon/Engine.js"
#include "kScriptsBeta/lib/JSXTAddon/Dialog.js"
#include "kScriptsBeta/lib/startup.js"

var JXParameters = {
    targetView: undefined,
    panels: 3,                 // grid size N (N x N panels)
    overlap: 256,              // overlap of neighbouring panels, px or % of the panel size
    overlapPercent: false,     // overlap unit: false = px, true = %
    blendMode: 0,              // weight ramp in the overlaps: 0 = cosine, 1 = linear
    generateStars: false,      // also join the StarXTerminator star images
    unscreen: false,           // StarXTerminator "Unscreen stars"
    sxtOverlap: 0.5            // StarXTerminator's own tile overlap
};

// Defaults for "Reset to defaults" (saved settings are loaded over JXParameters)
var JX_DEFAULTS = Object.assign({}, JXParameters);

function main() {
    startup();
    jxLoadSettings();
    JXParameters.panels = Math.max(JX_MIN_PANELS, Math.min(JX_MAX_PANELS, JXParameters.panels));

    if (!jxHasStarXTerminator()) {
        Console.criticalln("!!! Error: StarXTerminator is not installed. JSXTAddon needs the StarXTerminator process (RC Astro). !!!");
        new MessageBox(JX_NO_SXT_MESSAGE, TITLE, StdIcon_Error, StdButton_Ok).execute();
    }

    let dialog = new jxDialog();
    let retVal = dialog.execute();
    jxSaveSettings();

    if (retVal != 1) {
        return;
    }

    let view = JXParameters.targetView;
    if (!view || view.isNull) {
        Console.criticalln("!!! Error: Select an image. !!!");
        return;
    }

    try {
        Console.noteln("Removing stars from " + view.id + " in panels...");
        jxRun(view, JXParameters);
        Console.noteln("JSXTAddon finished successfully.");
    } catch (error) {
        Console.criticalln("Error during processing: " + error.message);
    }
}

CoreApplication.ensureMinimumVersion( 1, 9, 4 );

main();
