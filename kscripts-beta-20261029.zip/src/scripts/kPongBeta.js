// ---------- kPong Script ----------
// Pong game for PixInsight - player vs CPU,
// optionally on top of the active image.
// part of • kScript Bundle •
// made with love by Igor Koprowicz (koperson)
// check out my astrobin https://www.astrobin.com/users/koperson/
// ---------------------------------------------

#feature-id kPongBeta : kScripts Beta > kPong
#feature-info kPong - Pong game, player vs CPU
#define TITLE "kPong"
#define VER "1.0-beta1"

#engine v8

#include <pjsr/StdCursor.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/KeyCodes.jsh>
#include <pjsr/FocusStyle.jsh>

#include "kScriptsBeta/lib/Common.js"
#include "kScriptsBeta/lib/STF.js"
#include "kScriptsBeta/lib/kPong/Engine.js"
#include "kScriptsBeta/lib/kPong/Dialog.js"
#include "kScriptsBeta/lib/startup.js"

var KPParameters = {
    imageBackground: true     // use the active image window as background
};

function main() {
    startup();
    if (ImageWindow.activeWindow.isNull) {
        KPParameters.imageBackground = false;
    }
    let dialog = new kpDialog();
    dialog.execute();
}

CoreApplication.ensureMinimumVersion( 1, 9, 4 );

main();
