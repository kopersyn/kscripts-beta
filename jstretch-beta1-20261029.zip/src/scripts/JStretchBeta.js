// ---------- JStretch Script ----------
// Stretches a linear image: optional histogram pre-stretch,
// ArcsinhStretch (star color) and MaskedStretch, one after another.
// part of • kScript Bundle •
// made with love by Igor Koprowicz (koperson)
// check out my astrobin https://www.astrobin.com/users/koperson/
// method by Jędrzej Adaszek
// ---------------------------------------------

#feature-id JStretchBeta : kScripts Beta > JStretch
#feature-info JStretch - Arcsinh + Masked Stretch method by Jędrzej Adaszek
#define TITLE "JStretch"
#define VER "1.0-beta1"

#engine v8

#include <pjsr/StdCursor.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdButton.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/DataType.jsh>

#include "kScriptsBeta/lib/ScrollControl.js"
#include "kScriptsBeta/lib/Common.js"
#include "kScriptsBeta/lib/STF.js"
#include "kScriptsBeta/lib/JStretch/Engine.js"
#include "kScriptsBeta/lib/JStretch/HistogramControl.js"
#include "kScriptsBeta/lib/JStretch/Dialog.js"
#include "kScriptsBeta/lib/startup.js"

var JParameters = {
    targetView: undefined,
    preStretch: true,         // histogram pre-stretch before Arcsinh
    preShadows: 0,            // HistogramTransformation shadows clipping
    preMidtones: 0.25,        // HistogramTransformation midtones balance
    preHighlights: 1,         // HistogramTransformation highlights clipping
    arcsinh: 10,              // ArcsinhStretch stretch factor (1-1000)
    bpSigma: 2.8,             // Arcsinh black point = background median - bpSigma * sigma
    targetBackground: 0.125,  // MaskedStretch target background
    iterations: 100,          // MaskedStretch iterations
    bgPreviewId: "",          // preview of the target image used as MaskedStretch background reference ("" = none)
    newImage: false,          // stretch a copy in a new window instead of the image itself
    previewMode: 0            // 0 = final result, 1 = after Arcsinh, 2 = pre-stretch only
};

// Defaults for "Reset to defaults" (saved settings are loaded over JParameters)
var JS_DEFAULTS = Object.assign({}, JParameters);

function main() {
    startup();
    jsLoadSettings();
    let dialog = new jDialog();
    let retVal = dialog.execute();
    jsSaveSettings();

    if (retVal != 1) {
        return;
    }

    let view = JParameters.targetView;
    if (!view || view.isNull) {
        Console.criticalln("!!! Error: Select a linear image to stretch. !!!");
        return;
    }
    if (!jsIsLinear(view)) {
        Console.criticalln("!!! Error: " + view.id + " is non-linear. JStretch works only with linear images. !!!");
        return;
    }

    try {
        // Background reference rect is read from the original window (a copy has no previews)
        let bgRect = jsBackgroundRect(view);
        if (JParameters.newImage) {
            view = jsDuplicateView(view);
        }
        Console.noteln("Stretching " + view.id + "...");
        jsRun(view, "final", bgRect, false);
        jsResetSTF(view);
        Console.noteln("JStretch finished successfully.");
    } catch (error) {
        Console.criticalln("Error during processing: " + error.message);
    }
}

CoreApplication.ensureMinimumVersion( 1, 9, 4 );

main();
